<?php
class Zend_View_Helper_JavascriptHelper extends Zend_View_Helper_Abstract
{  
    function javascriptHelper() {
	        //$request = Zend_Controller_Front::getInstance()->getRequest();
	      //  $file_uri = 'js/' . $request->getControllerName() . '/' . $request->getActionName() . '.js';
	       // $file_uri = 'js/cnbc/' . $request->getModuleName() . '.js';
	          // $file_uri = 'js/cnbc/' . $request->getModuleName() . '.js';
//	var_dump(file_exists($file_uri));
	//var_dump($file_uri);
	      //  if (file_exists($file_uri)) {
	        	
	        //	return $file_uri;
	           // $this->view->headScript()->appendFile('/' . $file_uri);
	             //$this->view->headScript()->appendFile('/source/public/' .$file_uri);
	      // }
	    }
	}