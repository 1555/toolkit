<?php

class Zend_View_Helper_Alertpreview extends Zend_View_Helper_Abstract
{
    public function alertpreview(){
    	
    	//$prefix =  $this->baseUrl();

        $prefix =  $_SERVER['SCRIPT_NAME'];
    	$bannerA = $this->view->bannerA;
		$bannerB = $this->view->bannerB;
    	  $alert = $this->view->alert;
		  $subdom = $this->view->subdom;
    	 $shows = $this->view->shows;
		 if(isset($this->view->promo)){
		  $promo = $this->view->promo;
		 } else {
		  unset($promo);
			 
	 }
    	
    	  $pdate = $this->formatDateForPage($alert['date']);
    	  
 // var_dump($promo);
    	
    //testcall()	
	
	$call = "alerts.init('$subdom');";  
	
	
    	  $alertpreview = "<html><head>
		<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
		<title>CNBC - GUEST ALERT</title>
		<script type='text/javascript' src='$prefix/js/cnbc/alerts.js'></script>
		<script type='text/javascript' src='$prefix/js/cnbc/ajax-connection.js'></script>
	</head>
	<!-- end head -->
	
	
	
	
<!-- body -->	
<body onLoad=";  

$alertpreview .= '"';

$alertpreview .= $call;

$alertpreview .= '"';

$alertpreview .= " id='ourBody' style='font-family:Arial, Helvetica, sans-serif; font-size: 12px; color: #BCBEC0;text-align: center'>

<!-- main alignment table -->

<div id='border' style='border:1px solid #CCCCCC; width:600px; margin:0 auto;'><!--  -->
<table width='600'  cellpadding='0' cellspacing='0' id='main_container'>

<!--<table width='600' FRAME=BOX border='1'  BORDERCOLORLIGHT=GREY BORDERCOLORDARK=WHITE cellpadding='0' cellspacing='0' align='center'><tr><td>-->


 <!-- Europe header banner -->
  <tr>
    <td id='banner'><a href='http://www.cnbc.com'><img border='0' src='http://".$subdom.".cnbceuropeshared.com/public/guest_alert/header.jpg' width='600' height='91' alt='CNBC' /></a></td>
  </tr>
  
  
  <!-- end Europe header banner -->
  
  <!-- main menu -->
  <tr>
    <td id='menu'>
	<table width='600' border='0' cellpadding='5' cellspacing='2' id='menu_table' style='background-image:url(http://".$subdom.".cnbceuropeshared.com/public/guest_alert/menu_back.jpg);'>
    <tr style='color:#FFF;font-weight:bold;font-size:12px'>
        <td>&nbsp;</td>
        <td><font face='Arial, Helvetica, sans-serif' color='#FFFFFF' size='2'><a href='http://www.cnbc.com/id/19794221/site/14081545/' style='text-decoration:none;color:#FFFFFF;'>NEWS</a></font></td>
        <td><font face='Arial, Helvetica, sans-serif' color='#FFFFFF' size='2'><a href='http://www.cnbc.com/id/15921552' style='text-decoration:none;color:#FFFFFF;'>MARKETS</a></font></td>
        <td><font face='Arial, Helvetica, sans-serif' color='#FFFFFF' size='2'><a href='http://www.cnbc.com/id/15839135' style='text-decoration:none;color:#FFFFFF;'>EARNINGS</a></font></td>
        <td><font face='Arial, Helvetica, sans-serif' color='#FFFFFF' size='2'><a href='http://www.cnbc.com/id/15839069' style='text-decoration:none;color:#FFFFFF;'>INVESTING</a></font></td>
        <td><font face='Arial, Helvetica, sans-serif' color='#FFFFFF' size='2'><a href='http://www.cnbc.com/id/15839263/site/14081545/?tabid=15839797&tabheader=false' style='text-decoration:none;color:#FFFFFF;'>VIDEO</a></font></td>
        <td><font face='Arial, Helvetica, sans-serif' color='#FFFFFF' size='2'><a href='http://www.cnbc.com/id/15838668/site/14081545/' style='text-decoration:none;color:#FFFFFF;'>CNBC TV</a></font></td>
        <td><font face='Arial, Helvetica, sans-serif' color='#FFFFFF' size='2'><a href='http://www.cnbc.com/id/30011296' style='color:#FFFFFF;text-decoration:none;color:#FFFFFF;'>CNBC 360</a></font></td></td>
        <td width='62px'><font face='Arial, Helvetica, sans-serif' color='#FFFFFF' size='2'><a href='https://login.cnbc.com/cas/login?service=https://register.cnbc.com/j_acegi_cas_security_check&login-view=register?__source=CNBC|newsnow|pfheader|2009|
' style='color:#FFFFFF;text-decoration:none;'>SIGN-IN</a></font></td>

        
      </tr>
    </table>
	</td>
  </tr>
  <!-- end main menu -->
  
  <!-- banner a table -->
  <tr>
    <td id='banner_a'>
	<table width='600' border='0' cellpadding='0' cellspacing='0' id='banner_a_table'>
      <tr style='height:10px;'>
        <td width='66' style='width:66px;'></td>
        <td width='468'></td>
        <td width='66' style='width:66px;'></td>
      </tr>
      <tr>
	   <td width='70' style='width:60px;'></td>
       <td id='banner_a_img'><font face='Arial, Helvetica, sans-serif' size='0px'>ADVERTISMENT</font><div id='banner_a_image'>$bannerA</div></td>
       <td width='70' style='width:60px;'></td>
	  </tr>
      <tr>
       <td width='70' style='width:60px;'></td>
        <td width='468'></td>
        <td width='70' style='width:60px;'></td>
      </tr>
    </table>
	</td>
  </tr>
   <!-- end banner a table -->
  
  <!- guests table -->
  <tr>
    <td id='guests'>
	<table width='500' border='0'  cellpadding='10' cellspacing='0' id='guest_table' >
		<tr id='appearing'>
			<td>
				<font face='Arial, Helvetica, sans-serif' color='#005480' size='4'><strong>Guests Appearing on $pdate</strong></font>
			</td>
		</tr>
      <!-- g table goes here -->
	  <tr>
	  <td>
	  <table background='http://".$subdom.".cnbceuropeshared.com/public/guest_alert/guest_bar.jpg' id='interviews_table' border='0'  cellpadding='2' cellspacing='0' width='580' align='center' >
	  <!-- table head data -->
		  <tr>
			  <th width='100' align='left' style='padding-left:10px;'><font face='Arial, Helvetica, sans-serif' color='#FFFFFF' size='2' >Time(CET)</font></th>
			  <th width='100' align='left'><font face='Arial, Helvetica, sans-serif' color='#FFFFFF' size='2' >Programme</font></th>
			  <th width='100' align='left'><font face='Arial, Helvetica, sans-serif' color='#FFFFFF' size='2' >Name & Title</font></th>
			  <th width='90' align='left'><font face='Arial, Helvetica, sans-serif' color='#FFFFFF' size='2' >Company</font></th>
			  <th width='90' align='left'><font face='Arial, Helvetica, sans-serif' color='#FFFFFF' size='2' >Topics</font></th>
			  <th width='70' align='left'><font face='Arial, Helvetica, sans-serif' color='#FFFFFF' size='2' >Reminder</font></th>
		  </tr>
	 <!-- end table head data -->"
		  ;
		  
	  $n = 0;
	  
	  foreach($shows as $s){
		  
		// var_dump($s);
		  
		  if($n%2){
		
		$col = 'background-color:#DDDDDD;';
		
	} else {
		$col = 'background-color:#FFFFFF;';
	}
		$n++;
		$time = $s['hrs'].':'.$s['mins'];
		$show = $s['title'];
		$company = $s['companyname'];
		$guesttitle = $s['guesttitle'];
		$guestname = $s['guestname'];
		$topic = $s['topic'];
		$showid = $s['id'];
		$description= $s['description'];
		$startForCal = $s['calstring'][0];
	    $endForCal = $s['calstring'][1];
		$subject = 'CNBC interview with '.$guestname.' ('.$company.')';
		$location = 'CNBC TV';
		
		  
		$alertpreview .="
		
		<!-- an individual interview -->
		<tr style='color:#005480;font-size:12px;height:auto;vertical-align:text-top;'>
			<td  width='70' align='left' style='padding-left:10px;font-weight:bold;$col;padding-top:5px;padding-bottom:10px;'><font face='Arial, Helvetica, sans-serif' color='#005480' size='2'>$time</font></td>
			<td  width='100' align='left' style='font-weight:bold;$col;padding-top:5px;padding-bottom:10px;'><font face='Arial, Helvetica, sans-serif' color='#005480' size='2'>$show</font></td>
			<td  width='100' align='left' style='$col;padding-top:5px;padding-bottom:10px;'><font face='Arial, Helvetica, sans-serif' color='#005480' size='2'><B>$guestname</B></font><br/><font face='Arial, Helvetica, sans-serif' color='#005480' size='2' style='regular'>$guesttitle</font></td>
			<td  width='100' align='left' style='font-weight:regular;$col;padding-top:5px;padding-bottom:10px;'><font face='Arial, Helvetica, sans-serif' color='#005480' size='2'><b>$company</b></font></td>
			<td  width='100' align='left' style='font-weight:regular;$col;padding-top:5px;padding-bottom:10px;'><font face='Arial, Helvetica, sans-serif' color='#005480' size='2'><b>$topic</b></font></td>
			<td  width='70' align='left' style='font-weight:regular;$col;padding-top:5px;padding-bottom:10px;'><a href='http://".$subdom.".cnbceuropeshared.com/public/includes/alert.php?start=$startForCal&end=$endForCal&subject=$subject&location=$location&description=$topic&showid=$showid'><img src='http://".$subdom.".cnbceuropeshared.com/public/guest_alert/add_btn.jpg' border=0 width='41' height='19' alt='add' style='padding-top:10px;'></a></td>
		
		
		</tr>
		<!-- end of an interview -->
		
		
		
		";
		
		
		 
		  
	  }
	  
	  
       $alertpreview .= "
	   
	   </table>
	    <hr noshade='noshade' size='1' color='#CCCCCC'/> 
	   <!-- end interviews Table -->
	   </td>
	   
	 
	   
      </tr>
	 
  <!-- g table ends here -->
   <!-- begin A -->
  <!-- <tr><td cellspacing='0' cellpadding='0' > this thows out the guest table -->
  <table id='a' width='580px' align='center' style='text-align:left;'height='600px' ><tr><td cellspacing='0' cellpadding='0' style='padding:0px;vertical-align:top;'>
  
 
     <!-- begin B-->
 <table id='b' cellspacing='0' cellpadding='0' width='100%' height='600px' style='margin:0px;'>
 <!-- spacer row to push promo down now font-size is being used to style 'advertisment' above banner b  
		
		<tr>
		 
			<td>
				<img src='http://".$subdom.".cnbceuropeshared.com/public/guest_alert/spacer.gif'  width='0px' height='0px'>
			</td>
		</tr>   -->
		<!-- end spacer row -->
  <!-- promos table -->
  <tr>
    <td id='promos' height='100px'>
		<table  border='0' cellspacing='0' cellpadding='0'  height='130px' style='margin:0px;'>
		
		<!-- end spacer row -->
					<tr>
					$promo
					</tr>
		</table>
	</td>
  </tr>
  <!-- end promos table -->
         
         <!-- news head -->
		 <tr id='news head'>
		 
			 <td height='30px' width='410px'><img src='http://".$subdom.".cnbceuropeshared.com/public/guest_alert/spacer.gif'  width='0px' height='2px'><span style='line-height:52px; color:#666; font-family:Arial, Helvetica, sans-serif; font-size:16px;padding-top:10px;'>CNBC TOP NEWS AND VIDEOS</span><br/>
				<span id='top_stories_list' style='display:block;padding-bottom:10px;padding-top:7px;'></span>
			 </td>
		 </tr>
		 <!-- end news head -->
		 
		 <!-- blog head -->
		 
          <tr id='blog_head' valign='top'>
			   <td style='text-align:top;'><span style='line-height:32px; color:#666; font-family:Arial, Helvetica, sans-serif; font-size:16px;'>ON THE BLOGS</span><br>
				<span id='blogs_list'></span>
			   </td>
          </tr>
		  <!-- end blog head -->
		  
		  
         <!-- FB & Twitter-->
          <tr id='twitter'>
		  
            <td valign='bottom' height='30'>
				<!-- face book image -->
				<a href='http://www.facebook.com/cnbc' style='padding-left:0px;'><img src='http://".$subdom.".cnbceuropeshared.com/public/guest_alert/facebook.gif' border='0' ></a>
				<!-- end face book img -->
					<!-- face book link
				<a href='http://www.facebook.com/cnbc' style='text-decoration:none;'><font face='Arial, Helvetica, sans-serif' color='#009DDC' size='2'>Like us on Facebook</font></a>-->
				<!-- end face book link -->
				
				<!-- twitter image -->
				<a href='http://twitter.com/#!/CNBCWorld'><img src='http://".$subdom.".cnbceuropeshared.com/public/guest_alert/twitter.gif' border='0' style='padding-left:5px;'></a>
				<!-- you tube logo -->
				<a href='http://www.youtube.com/user/cnbc '><img src='http://".$subdom.".cnbceuropeshared.com/public/guest_alert/youtube.gif' border='0' style='padding-left:5px;'></a>
				
				<!-- end twiter img-->
				
				<!-- twittre link 
				<a href='http://twitter.com/#!/CNBCWorld' style='text-decoration:none;'><font face='Arial, Helvetica, sans-serif' color='#009DDC' size='2'>Follow us on Twitter</font></a>-->
			
			
		<!-- end twittre FB -->
			
			
          	<td><tr></table>
       <!-- end B -->
	   
        <td  id='banner_b_img' width='160' height='600' style='vertical-align:top;'><div id='banner_b_image'>$bannerB</div><font face='Arial, Helvetica, sans-serif' size='0px'>ADVERTISMENT</font></td>
		
		</table>
        <!-- end A -->
 
  <table width='100%' background='http://".$subdom.".cnbceuropeshared.com/public/guest_alert/links_bar.jpg' border='0' cellspacing='0' cellpadding='0'>
  <tr  height='24px'>
  <td><img src='http://".$subdom.".cnbceuropeshared.com/public/guest_alert/spacer.gif' width='8px'><a href='http://www.cnbc.com/id/35083111' style='text-decoration:none;color:#FFFFFF;'><font face='Arial, Helvetica, sans-serif' color='#FFFFFF' size='2'>Advertise</font></a> | <a href='https://login.cnbc.com/cas/login?service=https://register.cnbc.com/j_acegi_cas_security_check&login_view=register
' style='text-decoration:none;color:#FFFFFF;'><font face='Arial, Helvetica, sans-serif' color='#FFFFFF' size='2'>CNBC.com Member Centre</font></a> | <!--<a href='https://login.cnbc.com/cas/login?service=https%3A%2F%2Fregister.cnbc.com%2Fj_acegi_cas_security_check&login_view=register' style='text-decoration:none; color:#FFFFFF;'><font face='Arial, Helvetica, sans-serif' color='#FFFFFF' size='2'>Subscribe</font></a> | --><a href='http://cnbc.sparklist.com/u?id=%%memberidchar%%&o=%%outmail.messageid%%&n=T&e=%%emailaddr%%&l=%%list.name%%' style='text-decoration:none; color:#FFFFFF;'><font face='Arial, Helvetica, sans-serif' color='#FFFFFF' size='2'>Unsubscribe</font></a><!-- | <form action='http://toolkit-stage.cnbceuropeshared.com/public/'><input type='text' name='friendsemail'><input type='submit' value='submit'></form>--></td>
    
  </tr>
  <tr bgcolor='#414042' style='background-color:#DDDDDD;'>
    <td height='70px'   id='footer'><table  width='100%' border='0' cellspacing='0' cellpadding='5'>
      <tr>
        <td bgcolor='#414042'><img src='http://".$subdom.".cnbceuropeshared.com/public/guest_alert/logo.gif' width='215' height='39' alt='CNBC Logo' /></td>
      </tr>
      <tr height='15'>
        <td bgcolor='#414042'><img src='http://".$subdom.".cnbceuropeshared.com/public/guest_alert/spacer.gif' height='1' width='3'><font face='Arial, Helvetica, sans-serif' color='#FFFFFF' size='1'><img src='http://toolkit.cnbceuropeshared.com/public/newsletter/copyright.gif' width='7' height='7' alt='copyright' /> 2012 CNBC (UK) Limited. 10 Fleet Place London EC4M 7QS. All rights reserved</font></td>
      </tr>
    </table></td>
  </tr>
  
<!--</table><td><tr>-->
</table>
</div>



</body>
</html>";

return $alertpreview;


	}
	function formatDateForPage($d){
	
	date_default_timezone_set('GMT');
	
	$date = explode('-', $d);
	
	//var_dump($date) ;
	
	return date('l, j F  Y',mktime(0,0,0,$date[1],$date[2],(int)$date[0]));   //strtoupper(
	
	
}
}