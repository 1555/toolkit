<?php 

echo "<p>Sausage</p>";

?>