<?php

class Zwas_Db_Exception extends Zwas_Exception {

}
