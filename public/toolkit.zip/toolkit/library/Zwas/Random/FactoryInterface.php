<?php
interface Zwas_Random_FactoryInterface {
	public static function uniqId();
	public static function randomPassword();
}