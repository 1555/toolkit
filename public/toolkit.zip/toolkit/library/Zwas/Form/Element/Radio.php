<?php

require_once ('Zend/Form/Element/Radio.php');
class Zwas_Form_Element_Radio extends Zend_Form_Element_Radio {

}

