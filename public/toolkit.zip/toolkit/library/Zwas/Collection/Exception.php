<?php
class Zwas_Collection_Exception extends Zwas_Exception {
	
}