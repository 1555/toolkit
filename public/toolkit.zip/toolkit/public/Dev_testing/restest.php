<?

echo "hi there";

?>