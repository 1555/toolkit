<?php 

echo phpinfo();

?>