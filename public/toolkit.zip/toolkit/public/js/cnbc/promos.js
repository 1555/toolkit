/**
 * @author 127003597 aka Edward Hunton (opps)
 */

function grab(){
	
	// wrangle stuff for image
	// gets current value of select
	
	// go to the data base and grabs rest of image data
	//alert('sdfsdfsdfsdfsdfsdfsdf');
	promo_image_id = window.parent.document.forms['promo'].elements['image_id'].value;
	 
	//alert(promo_image_id);
	
	promo_title = window.parent.document.getElementById("promotitle").value; 
	
	promo_text = window.parent.document.getElementById("promocontent").value;    
	
	promo_link = window.parent.document.getElementById("link").value; 
	
	
}
	
	



function bang(){
	alert('test');
}