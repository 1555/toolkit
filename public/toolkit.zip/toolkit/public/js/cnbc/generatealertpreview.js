/**
 * @author 127003597
 */

 
 // get the date
 
 
 // get the campaign id and the compnay id from the banner a drop down value - ajax call to models
 
 // grab html from editor
 
 // grab interviews - show, start time, guestname, guesttitle, companyname, topic, description - loop through divs based on current value of theValue
 
 // 
 
 function gatherValuesAndPreview(){
 	alert("sdfdsfsdf");
	
	
	
 }
