({
		previousMessage: "Predchádzajúce voľby",
		nextMessage: "Ďalšie voľby"
})

