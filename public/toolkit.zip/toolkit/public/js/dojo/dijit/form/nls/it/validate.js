({
	invalidMessage: "Il valore immesso non è valido.",
	missingMessage: "Questo valore è obbligatorio.",
	rangeMessage: "Questo valore non è compreso nell'intervallo."
})
